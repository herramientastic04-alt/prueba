# Login con base de datos en Netlify

Ejemplo de registro (nombre, correo, contraseña) e inicio de sesión que funciona en Netlify con **Netlify Database** (Postgres). Las contraseñas se guardan cifradas y la sesión dura 7 días.

## Qué hay en la carpeta

```
public/index.html                              ← la página (registro, ingreso y bienvenida)
netlify/functions/registro.mjs                 ← POST /api/registro
netlify/functions/ingresar.mjs                 ← POST /api/ingresar
netlify/functions/yo.mjs                       ← GET  /api/yo   (¿quién tiene la sesión abierta?)
netlify/functions/salir.mjs                    ← POST /api/salir
netlify/database/migrations/0001_crear_usuarios.sql  ← crea las tablas
lib/auth.mjs                                   ← código compartido (cifrado, sesiones)
package.json, netlify.toml                     ← configuración
```

No hay que crear la base de datos a mano: al desplegar, Netlify ve el paquete `@netlify/database`, crea la base y ejecuta el archivo de la carpeta `migrations`.

## Cómo publicarlo

> **Ojo:** arrastrar la carpeta a Netlify (Netlify Drop) **no sirve** para este proyecto, porque ese método no ejecuta funciones. Usa una de estas dos opciones.

### Opción A — Con GitHub (sin usar la terminal)

1. Crea un repositorio nuevo en GitHub.
2. Pulsa **Add file → Upload files** y arrastra **el contenido** de esta carpeta (no la carpeta misma, para que `package.json` quede en la raíz). Confirma con **Commit changes**.
3. En Netlify: **Add new project → Import an existing project → GitHub** y elige el repositorio.
4. Deja la configuración como viene (la toma de `netlify.toml`) y pulsa **Deploy**.
5. Cuando termine, abre la dirección `https://tu-proyecto.netlify.app` y crea una cuenta.

Cada vez que cambies algo en GitHub, Netlify vuelve a publicar solo.

### Opción B — Con la terminal (Netlify CLI)

```bash
npm install
npx netlify login
npx netlify init          # vincula la carpeta con un proyecto de Netlify
npx netlify deploy --prod
```

Para probarlo en tu computador antes de publicar: `npx netlify dev` (levanta una base Postgres local).

## Ver los usuarios registrados

En Netlify, abre el proyecto → **Data & Storage → Database**. Ahí aparecen las tablas `usuarios` y `sesiones`. La columna `clave_hash` muestra la contraseña cifrada, nunca la real.

## Requisitos y límites

- Netlify Database solo funciona en los **planes por créditos** (las cuentas nuevas, incluido el plan Free, ya lo son). Si tu cuenta es antigua (plan *legacy*), Netlify te pedirá cambiar de plan.
- En el plan Free la base **se duerme tras 5 minutos sin uso**; la primera petición después de eso puede tardar un par de segundos.
- El plan Free permite 3 bases de datos y un consumo mensual limitado, suficiente para pruebas y proyectos pequeños.

## Agregar otro campo al registro (ejemplo: teléfono)

1. Crea `netlify/database/migrations/0002_agregar_telefono.sql` con:
   ```sql
   ALTER TABLE usuarios ADD COLUMN telefono TEXT;
   ```
   (nunca edites la migración 0001 después de publicada; siempre agrega una nueva).
2. Añade el `<input name="telefono">` en `public/index.html`.
3. En `registro.mjs`, lee `datos.telefono` e inclúyelo en el `INSERT`.
