// POST /api/registro  →  { nombre, correo, clave }
import { db, json, leerCuerpo, limpiarCorreo, correoValido, cifrarClave, crearSesion } from "../../lib/auth.mjs";

export default async (req) => {
  const datos = await leerCuerpo(req);
  if (!datos) return json({ error: "Solicitud no válida." }, 400);

  const nombre = String(datos.nombre ?? "").trim();
  const correo = limpiarCorreo(datos.correo);
  const clave = String(datos.clave ?? "");

  if (nombre.length < 2 || nombre.length > 80) {
    return json({ error: "Escribe un nombre de 2 a 80 caracteres." }, 400);
  }
  if (!correoValido(correo)) {
    return json({ error: "Escribe un correo electrónico válido." }, 400);
  }
  if (clave.length < 8 || clave.length > 200) {
    return json({ error: "La contraseña debe tener al menos 8 caracteres." }, 400);
  }

  try {
    const claveHash = await cifrarClave(clave);
    const filas = await db().sql`
      INSERT INTO usuarios (nombre, correo, clave_hash)
      VALUES (${nombre}, ${correo}, ${claveHash})
      ON CONFLICT (correo) DO NOTHING
      RETURNING id, nombre, correo
    `;
    if (filas.length === 0) {
      return json({ error: "Ese correo ya está registrado." }, 409);
    }

    const usuario = filas[0];
    const cookie = await crearSesion(usuario.id);
    return json(
      { usuario: { nombre: usuario.nombre, correo: usuario.correo } },
      201,
      { "set-cookie": cookie }
    );
  } catch (err) {
    console.error("Error en registro:", err);
    return json({ error: "No se pudo crear la cuenta. Intenta de nuevo." }, 500);
  }
};

export const config = { path: "/api/registro", method: "POST" };
