// POST /api/ingresar  →  { correo, clave }
import { db, json, leerCuerpo, limpiarCorreo, verificarClave, hashFicticio, crearSesion } from "../../lib/auth.mjs";

export default async (req) => {
  const datos = await leerCuerpo(req);
  if (!datos) return json({ error: "Solicitud no válida." }, 400);

  const correo = limpiarCorreo(datos.correo);
  const clave = String(datos.clave ?? "");
  if (!correo || !clave) {
    return json({ error: "Escribe tu correo y tu contraseña." }, 400);
  }

  try {
    const filas = await db().sql`
      SELECT id, nombre, correo, clave_hash FROM usuarios WHERE correo = ${correo}
    `;
    const usuario = filas[0];

    // Se verifica siempre (aunque el correo no exista) para no revelar qué correos están registrados.
    const ok = await verificarClave(clave, usuario ? usuario.clave_hash : await hashFicticio());
    if (!usuario || !ok) {
      return json({ error: "Correo o contraseña incorrectos." }, 401);
    }

    const cookie = await crearSesion(usuario.id);
    return json(
      { usuario: { nombre: usuario.nombre, correo: usuario.correo } },
      200,
      { "set-cookie": cookie }
    );
  } catch (err) {
    console.error("Error al ingresar:", err);
    return json({ error: "No se pudo iniciar sesión. Intenta de nuevo." }, 500);
  }
};

export const config = { path: "/api/ingresar", method: "POST" };
