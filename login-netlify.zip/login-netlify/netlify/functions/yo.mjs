// GET /api/yo  →  datos del usuario con sesión activa
import { json, usuarioActual } from "../../lib/auth.mjs";

export default async (req) => {
  try {
    const usuario = await usuarioActual(req);
    if (!usuario) return json({ usuario: null }, 401);
    return json({ usuario: { nombre: usuario.nombre, correo: usuario.correo } });
  } catch (err) {
    console.error("Error al leer la sesión:", err);
    return json({ error: "No se pudo verificar la sesión." }, 500);
  }
};

export const config = { path: "/api/yo", method: "GET" };
