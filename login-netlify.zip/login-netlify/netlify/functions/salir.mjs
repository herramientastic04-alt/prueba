// POST /api/salir  →  cierra la sesión
import { json, cerrarSesion } from "../../lib/auth.mjs";

export default async (req) => {
  try {
    const cookie = await cerrarSesion(req);
    return json({ ok: true }, 200, { "set-cookie": cookie });
  } catch (err) {
    console.error("Error al cerrar sesión:", err);
    return json({ error: "No se pudo cerrar la sesión." }, 500);
  }
};

export const config = { path: "/api/salir", method: "POST" };
