-- Netlify aplica este archivo automáticamente al desplegar.
-- Crea la tabla de usuarios (los 3 campos del registro) y la de sesiones.

CREATE TABLE usuarios (
  id          SERIAL PRIMARY KEY,
  nombre      TEXT        NOT NULL,
  correo      TEXT        NOT NULL UNIQUE,
  clave_hash  TEXT        NOT NULL,          -- la contraseña nunca se guarda en texto plano
  creado_en   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sesiones (
  token_hash  TEXT        PRIMARY KEY,
  usuario_id  INTEGER     NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  creada_en   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expira_en   TIMESTAMPTZ NOT NULL
);

CREATE INDEX sesiones_usuario_idx ON sesiones (usuario_id);
